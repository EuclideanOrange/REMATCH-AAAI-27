"""Draw the matching and paired-change panels of the AIDev main figure."""

import matplotlib.lines as mlines
import matplotlib.patches as mpatches

STAGE_SPECS = [
    ("all_closed_prs", "All eligible PRs (repo-month)", 0.0, "eligibility"),
    ("all_prs_in_exact_commit_months", "Exact-commit months (all PRs)", 1.0, "eligibility"),
    ("multi_prs_in_exact_commit_months", "Exact-commit months (≥2 commits)", 2.0, "eligibility"),
    ("exact_commit_sample_by_month", "Exact-commit PRs: repo-month", 3.3, "before"),
    ("exact_commits", "Exact-commit PRs: + exact commits", 4.25, "after"),
    ("file_band_sample_by_exact_commits", "File-band PRs: exact commits", 5.55, "before"),
    ("exact_commits_file_band", "File-band PRs: + file-count band", 6.5, "after"),
]

PAIRED_SPECS = [
    ("paired_exact_commit_change", "Add exact commits", 3.775, "#1b4965"),
    ("paired_file_band_change", "Add file-count band", 6.025, "#1b4965"),
]


def _fmt_pp(value):
    """Format a signed percentage-point value using a typographic minus sign."""
    text = f"{value:+.2f}"
    return text.replace("-", "\u2212")


def draw_matching_panel(ax_left, stage_rows):
    # Panel A gridlines (skip x=0 where the dashed zero reference sits).
    for xtick in (10, 20, 30):
        ax_left.axvline(xtick, color="#d0d5dd", linestyle=":", linewidth=0.65, zorder=0)
    ax_left.axvline(0.0, color="#333333", linestyle="--", linewidth=0.85, zorder=1)

    styles = {
        "eligibility": dict(
            color="#33415c", marker="o", mfc="#33415c", mec="#33415c", ms=5.2, mew=1.0
        ),
        "before": dict(color="#1b4965", marker="s", mfc="white", mec="#1b4965", ms=5.5, mew=1.4),
        "after": dict(color="#9b2226", marker="D", mfc="#9b2226", mec="#9b2226", ms=5.3, mew=1.0),
    }

    y_ticks = []
    y_labels = []
    for _, title, y, kind, row in stage_rows:
        est = 100.0 * float(row["estimate"])
        lo = 100.0 * float(row["ci_low"])
        hi = 100.0 * float(row["ci_high"])
        prs = int(row["prs"])
        repos = int(row["repositories"])
        st = styles[kind]

        ax_left.plot([lo, hi], [y, y], color=st["color"], linewidth=1.6, zorder=2)
        ax_left.plot(
            est,
            y,
            marker=st["marker"],
            markerfacecolor=st["mfc"],
            markeredgecolor=st["mec"],
            markersize=st["ms"],
            markeredgewidth=st["mew"],
            linestyle="none",
            zorder=3,
        )
        ax_left.text(
            hi + 1.0,
            y,
            _fmt_pp(est),
            va="center",
            ha="left",
            fontsize=9.0,
            color="#111111",
        )
        y_ticks.append(y)
        y_labels.append(f"{title}\n({prs:,} PRs, {repos} repos)")

    ax_left.set_yticks(y_ticks)
    ax_left.set_yticklabels(y_labels, linespacing=1.12)
    ax_left.set_xlim(-6.5, 39.5)
    ax_left.set_xticks([0, 10, 20, 30])
    ax_left.set_xlabel("Codex − Claude Code (pp)")
    ax_left.set_title("A. Revisit gap across matching steps", fontweight="bold", pad=6)


def draw_paired_panel(ax_right, paired_rows, y_max, band_color):
    # Panel B gridlines and zero reference only in the paired-band data region.
    for xtick in (-2, -1, 1, 2):
        ax_right.plot(
            [xtick, xtick],
            [2.65, y_max],
            color="#d0d5dd",
            linestyle=":",
            linewidth=0.65,
            zorder=0,
        )
    ax_right.plot(
        [0.0, 0.0], [2.65, y_max], color="#333333", linestyle="--", linewidth=0.85, zorder=1
    )

    label_bbox = dict(facecolor=band_color, edgecolor="none", pad=1.2)
    for _, label, y, color, row in paired_rows:
        est = 100.0 * float(row["estimate"])
        lo = 100.0 * float(row["ci_low"])
        hi = 100.0 * float(row["ci_high"])

        ax_right.plot([lo, hi], [y, y], color=color, linewidth=1.7, zorder=2)
        ax_right.plot(
            est,
            y,
            marker="^",
            markerfacecolor=color,
            markeredgecolor=color,
            markersize=6.0,
            linestyle="none",
            zorder=3,
        )
        ax_right.text(
            0.0,
            y - 0.50,
            label,
            va="center",
            ha="center",
            fontsize=9.0,
            color="#111111",
            bbox=label_bbox,
            zorder=4,
        )
        ax_right.text(
            0.0,
            y + 0.48,
            f"{_fmt_pp(est)} pp [{_fmt_pp(lo)}, {_fmt_pp(hi)}]",
            va="center",
            ha="center",
            fontsize=9.0,
            color=color,
            fontweight="bold",
            bbox=label_bbox,
            zorder=4,
        )

    ax_right.set_yticks([])
    ax_right.spines["left"].set_visible(False)
    ax_right.set_xlim(-2.6, 2.6)
    ax_right.set_xticks([-2, -1, 0, 1, 2])
    ax_right.set_xticklabels(["\u22122", "\u22121", "0", "1", "2"])
    ax_right.set_xlabel("After − Before (pp)")
    ax_right.set_title("B. Paired shift on fixed PRs", fontweight="bold", pad=6)

    legend_handles = [
        mlines.Line2D(
            [], [], color="#33415c", marker="o", ms=5.2, lw=1.5, label="Eligibility restriction"
        ),
        mlines.Line2D(
            [],
            [],
            color="#1b4965",
            marker="s",
            mfc="white",
            mec="#1b4965",
            mew=1.4,
            ms=5.5,
            lw=1.5,
            label="Fixed PRs: before match",
        ),
        mlines.Line2D(
            [], [], color="#9b2226", marker="D", ms=5.3, lw=1.5, label="Fixed PRs: after match"
        ),
        mlines.Line2D(
            [], [], color="#1b4965", marker="^", ms=5.8, lw=1.6, label="Paired shift (95% CI)"
        ),
        mpatches.Patch(facecolor=band_color, edgecolor="#cccccc", label="Identical PR set"),
    ]
    ax_right.legend(
        handles=legend_handles,
        loc="upper center",
        bbox_to_anchor=(0.5, 0.995),
        frameon=True,
        facecolor="white",
        edgecolor="#cccccc",
        framealpha=1.0,
        borderpad=0.45,
        handlelength=1.4,
        labelspacing=0.35,
    )
