"""Render the AAAI-2027 manuscript main figure strictly from canonical summary.csv.

Usage:
    python -m figures.main_figure --summary results/aidev_revisit/summary.csv \
        --output results/aidev_revisit/main_figure.pdf \
        --png results/aidev_revisit/main_figure.png
"""

import argparse
import sys
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd

if not __package__:
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from figures.revisit_panels import PAIRED_SPECS, STAGE_SPECS, draw_matching_panel, draw_paired_panel

PAIR_BANDS = [
    (2.82, 4.73),
    (5.07, 6.98),
]


def _lookup_row(summary, analysis, metric="any_revisit"):
    matches = summary.loc[(summary["analysis"] == analysis) & (summary["metric"] == metric)]
    if len(matches) != 1:
        raise ValueError(
            f"Expected exactly 1 row for analysis={analysis!r}, metric={metric!r}; found {len(matches)}"
        )
    return matches.iloc[0]


def render_main_figure(summary_csv, output_pdf, *, png_path=None):
    """Build the two-column AAAI figure reading all numbers from summary_csv."""
    summary_csv = Path(summary_csv)
    output_pdf = Path(output_pdf)
    summary = pd.read_csv(summary_csv)

    stage_rows = [
        (analysis, title, y, kind, _lookup_row(summary, analysis, "any_revisit"))
        for analysis, title, y, kind in STAGE_SPECS
    ]
    paired_rows = [
        (analysis, title, y, color, _lookup_row(summary, analysis, "any_revisit"))
        for analysis, title, y, color in PAIRED_SPECS
    ]

    rc = {
        "font.family": "serif",
        "font.serif": ["Times New Roman", "Times", "Nimbus Roman", "DejaVu Serif"],
        "font.size": 9.0,
        "axes.labelsize": 9.5,
        "axes.titlesize": 9.5,
        "xtick.labelsize": 9.0,
        "ytick.labelsize": 9.0,
        "legend.fontsize": 9.0,
        "axes.linewidth": 0.75,
        "grid.linewidth": 0.6,
        "lines.linewidth": 1.3,
        "pdf.fonttype": 42,
        "ps.fonttype": 42,
    }

    with plt.rc_context(rc):
        fig, (ax_left, ax_right) = plt.subplots(
            1,
            2,
            figsize=(6.8, 4.15),
            gridspec_kw={"width_ratios": [1.48, 1.04], "wspace": 0.12},
        )

        y_min, y_max = -0.62, 7.12
        band_color = "#eef2f6"
        for ax in (ax_left, ax_right):
            for band_top, band_bottom in PAIR_BANDS:
                ax.axhspan(band_top, band_bottom, color=band_color, zorder=0)
            ax.set_ylim(y_max, y_min)
            ax.spines["top"].set_visible(False)
            ax.spines["right"].set_visible(False)

        draw_matching_panel(ax_left, stage_rows)
        draw_paired_panel(ax_right, paired_rows, y_max, band_color)

        fig.subplots_adjust(left=0.355, right=0.985, top=0.915, bottom=0.13)

        output_pdf.parent.mkdir(parents=True, exist_ok=True)
        fig.savefig(output_pdf)
        if png_path is not None:
            png_path = Path(png_path)
            png_path.parent.mkdir(parents=True, exist_ok=True)
            fig.savefig(png_path, dpi=300)
        plt.close(fig)

    return output_pdf


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--summary",
        type=Path,
        default=Path("results/aidev_revisit/summary.csv"),
        help="Path to the canonical summary.csv table.",
    )
    parser.add_argument(
        "--output",
        type=Path,
        default=Path("results/aidev_revisit/main_figure.pdf"),
        help="Output vector PDF path.",
    )
    parser.add_argument(
        "--png",
        type=Path,
        default=None,
        help="Optional 300 dpi PNG output path.",
    )
    args = parser.parse_args()
    render_main_figure(args.summary, args.output, png_path=args.png)
    print(f"Wrote {args.output}")
    if args.png is not None:
        print(f"Wrote {args.png}")


if __name__ == "__main__":
    main()
