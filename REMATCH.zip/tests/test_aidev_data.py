import pyarrow as pa
import pyarrow.parquet as pq
import pytest

from data.aidev_history import CommitFileAggregator, stage
from data.load_aidev import select_aidev_cohort
from data.utils import AIDEV_CONFIG
from experiments.revisit_analysis import AGENTS


def test_raw_deduplication_conflicts_and_commit_coverage(tmp_path):
    pq.write_table(
        pa.Table.from_pylist([dict(pr_id=1, sha=s) for s in ["a", "b"]]),
        tmp_path / "pr_commits.parquet",
    )
    rows = [
        dict(pr_id=1, sha=s, filename=p, additions=1.0, deletions=0.0)
        for s, p in [("a", "x"), ("b", "x"), ("a", "y"), ("a", "x")]
    ]
    pq.write_table(pa.Table.from_pylist(rows), tmp_path / "pr_commit_details.parquet")
    result, audit = stage(tmp_path, {1}, tmp_path / "ok.sqlite")
    assert audit["duplicate_file_rows"] == 1
    assert result.loc[0, "revisited_files"] == 1
    assert result.loc[0, "file_commit_events"] == 3
    rows[-1]["additions"] = 2.0
    pq.write_table(pa.Table.from_pylist(rows), tmp_path / "pr_commit_details.parquet")
    with pytest.raises(ValueError):
        stage(tmp_path, {1}, tmp_path / "conflict.sqlite")
    pq.write_table(pa.Table.from_pylist(rows[:1]), tmp_path / "pr_commit_details.parquet")
    with pytest.raises(ValueError):
        stage(tmp_path, {1}, tmp_path / "missing.sqlite")


def test_cohort_selection_and_commit_file_aggregator():
    pr_rows = []
    pr_id = 1
    for repo in ("https://api.github.com/repos/o/r1", "https://api.github.com/repos/o/r2"):
        for agent in AGENTS:
            for _ in range(3):
                pr_rows.append(
                    dict(
                        id=pr_id,
                        number=pr_id,
                        agent=agent,
                        user="u",
                        title="fix bug",
                        state="closed",
                        created_at="2026-02-01T00:00:00Z",
                        closed_at="2026-02-02T00:00:00Z",
                        merged_at="2026-02-02T00:00:00Z",
                        repo_url=repo,
                        html_url=f"https://github.com/o/r/pull/{pr_id}",
                    )
                )
                pr_id += 1
    # Add one PR closed after cutoff that must be excluded.
    pr_rows.append(
        dict(
            id=999,
            number=999,
            agent=AGENTS[0],
            user="u",
            title="late",
            state="closed",
            created_at="2026-03-31T00:00:00Z",
            closed_at="2026-04-01T00:00:00Z",
            merged_at=None,
            repo_url="https://api.github.com/repos/o/r1",
            html_url="https://github.com/o/r/pull/999",
        )
    )
    repos = {
        "https://api.github.com/repos/o/r1": {
            "url": "https://api.github.com/repos/o/r1",
            "language": "Python",
        },
        "https://api.github.com/repos/o/r2": {
            "url": "https://api.github.com/repos/o/r2",
            "language": "Rust",
        },
    }
    capped_cfg = {**AIDEV_CONFIG, "max_repositories": 1, "max_prs_per_agent_repository": 2}
    capped, capped_audit = select_aidev_cohort(pr_rows, repos, capped_cfg)
    assert capped_audit["counts"]["selected_repositories"] == 1
    assert len(capped) == 4

    uncapped_cfg = {
        **AIDEV_CONFIG,
        "max_repositories": None,
        "max_prs_per_agent_repository": None,
    }
    uncapped, uncapped_audit = select_aidev_cohort(pr_rows, repos, uncapped_cfg)
    assert uncapped_audit["counts"]["excluded_invalid_metadata"] == 1
    assert len(uncapped) == 12

    agg = CommitFileAggregator(uncapped[:1])
    agg.add_commit(dict(pr_id=1, sha="s1", author="a", committer="a"))
    agg.add_file(dict(pr_id=1, sha="s1", filename="tests/test_a.py", additions=4, deletions=1))
    features, feat_audit = agg.finish(uncapped_cfg)
    assert feat_audit["retained_prs"] == 1
    assert features[0]["commit_count"] == 1
    assert features[0]["file_count"] == 1
    assert features[0]["test_file_fraction"] == 1.0
    assert features[0]["provenance_flag"] == "single_recorded_author"
