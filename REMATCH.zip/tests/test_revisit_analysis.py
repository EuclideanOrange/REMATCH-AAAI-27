import pandas as pd
import pytest

from experiments.revisit_analysis import (
    AGENTS,
    BASE,
    contrasts,
    derive,
    historical_file_band_sensitivity,
    paired_revisit_change,
    revisit_eligibility_checks,
    summarize,
    verify_paired_pr_ids,
)


def test_intensity_denominators_and_zero_churn():
    frame = pd.DataFrame(
        [
            dict(
                file_count=2,
                commit_count=3,
                file_commit_events=4,
                revisited_files=1,
                revisited_churn=8,
                additions=10,
                deletions=0,
            ),
            dict(
                file_count=1,
                commit_count=1,
                file_commit_events=1,
                revisited_files=0,
                revisited_churn=0,
                additions=0,
                deletions=0,
            ),
        ]
    )
    result = derive(frame)
    assert result.loc[0, "revisited_fraction"] == 0.5
    assert result.loc[0, "extra_touch_fraction"] == 0.5
    assert result.loc[0, "revisited_churn_share"] == 0.8
    assert result.loc[0, "file_band"] == 1
    assert result.loc[1, "any_revisit"] == 0
    assert result.loc[1, "file_band"] == 0
    assert pd.isna(result.loc[1, "extra_touch_fraction"])
    assert pd.isna(result.loc[1, "revisited_churn_share"])


def test_minimum_support_uses_nonmissing_outcomes():
    frame = pd.DataFrame(
        [
            dict(repo_url="r", agent=agent, outcome=value)
            for agent, values in [("a", [0.0, 0.0]), ("b", [1.0, float("nan")])]
            for value in values
        ]
    )
    assert contrasts(frame, ["repo_url"], "agent", ("a", "b"), ["outcome"]).empty


def test_equal_repository_weighting():
    cells = pd.DataFrame(
        [
            dict(repo_url=repo, metric="x", contrast=value, n_left=n, n_right=n)
            for repo, value, n in [("a", 1, 100), ("a", 1, 100), ("b", -1, 2)]
        ]
    )
    summary, _ = summarize(cells, "test", 200, 42)
    assert summary[0]["estimate"] == 0
    assert summary[0]["repositories"] == 2
    assert summary == summarize(cells, "test", 200, 42)[0]


def test_matching_eligibility_keeps_the_exact_pr_ids_for_each_paired_change():
    cases = [
        (AGENTS[0], 2, 0, [0, 0]),
        (AGENTS[1], 2, 0, [1, 1]),
        (AGENTS[0], 2, 1, [1, 1]),
        (AGENTS[0], 3, 1, [0, 0]),
        (AGENTS[1], 3, 1, [0, 0, 0, 0]),
        (AGENTS[0], 1, 0, [0, 0]),
        (AGENTS[1], 1, 0, [0, 0]),
    ]
    frame = pd.DataFrame(
        [
            dict(
                repo_url="repo",
                created_month="2025-09",
                agent=agent,
                commit_count=count,
                file_band=band,
                any_revisit=revisit,
                revisited_fraction=float(revisit) * 0.5,
            )
            for agent, count, band, revisits in cases
            for revisit in revisits
        ]
    ).reset_index(names="id")
    multi = frame.loc[frame.commit_count.ge(2)]
    exact = contrasts(multi, BASE, "agent", AGENTS, ("any_revisit", "revisited_fraction"))
    band = contrasts(
        multi, BASE + ["file_band"], "agent", AGENTS, ("any_revisit", "revisited_fraction")
    )
    analyses, membership = revisit_eligibility_checks(frame, exact, band)
    assert set(membership.id) == set(range(12))
    assert membership["in_exact_commit_sample"].all()
    assert set(membership.loc[membership.in_file_band_sample, "id"]) == set(range(12)) - {4, 5}

    paired_audit = verify_paired_pr_ids(
        frame,
        membership,
        analyses["exact_commit_sample_by_month"],
        exact,
        analyses["file_band_sample_by_exact_commits"],
        band,
    )
    assert paired_audit["exact_commit_before_prs"] == 12
    assert paired_audit["exact_commit_after_prs"] == 12
    assert paired_audit["exact_commit_identical_pr_ids"]
    assert paired_audit["file_band_before_prs"] == 10
    assert paired_audit["file_band_after_prs"] == 10
    assert paired_audit["file_band_identical_pr_ids"]

    exact_delta = paired_revisit_change(analyses["exact_commit_sample_by_month"], exact)
    assert round(exact_delta.contrast.item() - 0.25, 7) == 0
    band_delta = paired_revisit_change(
        analyses["file_band_sample_by_exact_commits"],
        band,
        metrics=("any_revisit", "revisited_fraction"),
    )
    assert set(band_delta.metric) == {"any_revisit", "revisited_fraction"}
    assert (band_delta.contrast.abs() < 1e-12).all()
    with pytest.raises(ValueError, match="same per-agent PR counts"):
        paired_revisit_change(analyses["exact_commit_sample_by_month"], band)


def test_historical_file_band_specification_uses_coarse_bands_and_positive_churn():
    # Files 5 and 9 fall into the same historical "4-10" band (different log2 bands 2 and 3),
    # while zero-churn PRs must be excluded before cell formation.
    rows = [
        dict(
            repo_url="r1",
            created_month="2026-01",
            commit_count=2,
            agent=AGENTS[0],
            file_count=5,
            additions=5,
            deletions=0,
            any_revisit=0,
        ),
        dict(
            repo_url="r1",
            created_month="2026-01",
            commit_count=2,
            agent=AGENTS[0],
            file_count=9,
            additions=5,
            deletions=0,
            any_revisit=0,
        ),
        dict(
            repo_url="r1",
            created_month="2026-01",
            commit_count=2,
            agent=AGENTS[1],
            file_count=6,
            additions=5,
            deletions=0,
            any_revisit=1,
        ),
        dict(
            repo_url="r1",
            created_month="2026-01",
            commit_count=2,
            agent=AGENTS[1],
            file_count=10,
            additions=5,
            deletions=0,
            any_revisit=1,
        ),
        # Zero-churn PR in a separate repo that would qualify only if zero churn were included.
        dict(
            repo_url="r2",
            created_month="2026-01",
            commit_count=2,
            agent=AGENTS[0],
            file_count=1,
            additions=0,
            deletions=0,
            any_revisit=1,
        ),
        dict(
            repo_url="r2",
            created_month="2026-01",
            commit_count=2,
            agent=AGENTS[0],
            file_count=1,
            additions=2,
            deletions=0,
            any_revisit=1,
        ),
        dict(
            repo_url="r2",
            created_month="2026-01",
            commit_count=2,
            agent=AGENTS[1],
            file_count=1,
            additions=2,
            deletions=0,
            any_revisit=0,
        ),
        dict(
            repo_url="r2",
            created_month="2026-01",
            commit_count=2,
            agent=AGENTS[1],
            file_count=1,
            additions=2,
            deletions=0,
            any_revisit=0,
        ),
    ]
    alt = historical_file_band_sensitivity(pd.DataFrame(rows), seed=42)
    row = alt.loc[alt.analysis == "historical_file_band_10000"].iloc[0]
    assert int(row["repositories"]) == 1
    assert int(row["prs"]) == 4
    assert round(float(row["estimate"]) - 1.0, 7) == 0
