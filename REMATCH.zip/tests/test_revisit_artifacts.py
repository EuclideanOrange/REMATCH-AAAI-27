import json
from pathlib import Path

import pandas as pd
import pytest

from experiments.revisit_artifacts import verify_against_reference
from figures.main_figure import render_main_figure

ROOT = Path(__file__).resolve().parent.parent
CANONICAL_DIR = ROOT / "results" / "aidev_revisit"
REFERENCE_DIR = ROOT / "results" / "aidev_revisit_extensions_2026-11-20"


def test_main_figure_reads_from_canonical_summary_csv(tmp_path):
    summary_csv = CANONICAL_DIR / "summary.csv"
    pdf_out = tmp_path / "figure.pdf"
    png_out = tmp_path / "figure.png"
    render_main_figure(summary_csv, pdf_out, png_path=png_out)
    assert pdf_out.is_file() and pdf_out.stat().st_size > 5000
    assert png_out.is_file() and png_out.stat().st_size > 5000

    # Removing a required analysis must fail loudly instead of silently plotting stale values.
    broken = pd.read_csv(summary_csv)
    broken = broken.loc[broken["analysis"] != "paired_file_band_change"]
    broken_csv = tmp_path / "broken.csv"
    broken.to_csv(broken_csv, index=False)
    with pytest.raises(ValueError):
        render_main_figure(broken_csv, tmp_path / "fail.pdf")


def test_committed_canonical_artifacts_match_reference_and_membership():
    verification = verify_against_reference(CANONICAL_DIR, REFERENCE_DIR)
    assert verification["summary_rows_checked"] == 22
    assert verification["repository_contrasts_checked"] == 1028
    assert verification["paired_exact_commit_prs"] == 4312
    assert verification["paired_file_band_prs"] == 1851

    audit = json.loads((CANONICAL_DIR / "audit.json").read_text(encoding="utf-8"))
    assert audit["paired_comparisons"]["exact_commit_identical_pr_ids"]
    assert audit["paired_comparisons"]["file_band_identical_pr_ids"]

    summary = pd.read_csv(CANONICAL_DIR / "summary.csv")

    def get(analysis, metric="any_revisit"):
        return summary.loc[(summary.analysis == analysis) & (summary.metric == metric)].iloc[0]

    assert round(100 * get("all_closed_prs")["estimate"] + 0.234873, 4) == 0
    assert int(get("all_closed_prs")["prs"]) == 23802
    assert int(get("all_closed_prs")["repositories"]) == 379

    assert round(100 * get("exact_commit_sample_by_month")["estimate"] - 9.414834, 4) == 0
    assert round(100 * get("exact_commits")["estimate"] - 8.640152, 4) == 0
    assert round(100 * get("paired_exact_commit_change")["estimate"] + 0.774682, 4) == 0

    assert round(100 * get("file_band_sample_by_exact_commits")["estimate"] - 18.529390, 4) == 0
    assert round(100 * get("exact_commits_file_band")["estimate"] - 18.800893, 4) == 0
    assert round(100 * get("paired_file_band_change")["estimate"] - 0.271503, 4) == 0

    # Verify PR membership counts match cell tables on both sides of each paired comparison.
    membership = pd.read_csv(CANONICAL_DIR / "matching_pr_membership.csv")
    assert len(membership) == 4312
    assert int(membership["in_file_band_sample"].sum()) == 1851
    for cells_file, subset in (
        ("exact_commit_sample_by_month_cells.csv", membership),
        ("exact_commits_cells.csv", membership),
        (
            "file_band_sample_by_exact_commits_cells.csv",
            membership[membership["in_file_band_sample"]],
        ),
        ("exact_commits_file_band_cells.csv", membership[membership["in_file_band_sample"]]),
    ):
        cells = pd.read_csv(CANONICAL_DIR / cells_file)
        cells = cells.loc[cells["metric"] == "any_revisit"]
        assert int((cells["n_left"] + cells["n_right"]).sum()) == len(subset)

    alt = pd.read_csv(CANONICAL_DIR / "alternate_specifications.csv")
    hist = alt.loc[alt["analysis"] == "historical_file_band_10000"].iloc[0]
    assert int(hist["repositories"]) == 58
    assert int(hist["prs"]) == 2489
    assert round(100 * float(hist["estimate"]) - 12.193287, 4) == 0

    assert (CANONICAL_DIR / "main_figure.pdf").is_file()
