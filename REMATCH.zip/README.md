# REMATCH: Re-Estimating Matched Comparisons between Codex and Claude Code

Code and saved results for a study of file revisits in Claude Code and OpenAI Codex pull requests from the [AIDev](https://huggingface.co/datasets/hao-li/AIDev) dataset.

## Contents

| Path | What it holds |
|---|---|
| `data/load_aidev.py` | Downloads the pinned AIDev Parquet files and builds the analysis inputs |
| `data/aidev_history.py` | Computes per-PR features from commit-file records and audits them against the raw history |
| `data/utils.py` | Pinned dataset revision, file hashes, and I/O helpers |
| `experiments/aidev_revisit_extensions.py` | Runs the study and writes the result tables |
| `experiments/revisit_analysis.py` | Revisit metrics, matching, and the repository bootstrap |
| `experiments/revisit_artifacts.py` | Checks a run against the reference run and writes the report |
| `figures/main_figure.py` | Draws the main figure from a run's `summary.csv` |
| `figures/revisit_panels.py` | Panel drawing used by `main_figure.py` |
| `figures/aidev_revisit_numbers.py` | Writes the paper's result macros (`revisit_numbers.tex`) from a run |
| `results/aidev_revisit/` | Saved run reported in the paper |
| `results/aidev_revisit_extensions_2026-11-20/` | Earlier reference run, used to check that a new run matches |
| `results/revisit_marginal_rates.csv` | Pooled revisit counts read by `aidev_revisit_numbers.py` |
| `tests/` | Unit tests and consistency checks on the saved results |
| `requirements.txt` | Python dependencies |
| `pyproject.toml` | Ruff settings |

## Running the scripts

Run every command from the repository root. Tested with Python 3.12.

### Set up

```bash
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -r requirements.txt pytest
```

### Use the saved results

These need no download.

```bash
python -m pytest tests
python -m figures.main_figure --output main_figure.pdf
python -m figures.aidev_revisit_numbers results/aidev_revisit revisit_numbers.tex
```

### Rerun the study from the raw data

1. Download the four pinned Parquet files (about 13 GB) into `cache/raw/aidev` and build the inputs in `cache/aidev_inputs`:

   ```bash
   python -m data.load_aidev --download --verify-hashes
   ```

2. Run the study into a new folder and check it against the reference run. The output folder must not exist yet.

   ```bash
   python -m experiments.aidev_revisit_extensions results/aidev_revisit_fresh \
     --verify-reference results/aidev_revisit_extensions_2026-11-20
   ```
