"""Revisit metrics, matched comparisons, and repository-level inference."""

import numpy as np
import pandas as pd

AGENTS = ("Claude_Code", "OpenAI_Codex")
METRICS = ("any_revisit", "revisited_fraction", "extra_touch_fraction", "revisited_churn_share")
BASE = ["repo_url", "created_month", "commit_count"]
HISTORICAL_BAND_EDGES = [0, 1, 3, 10, np.inf]
HISTORICAL_BAND_LABELS = ["1", "2-3", "4-10", "11+"]


def derive(frame):
    """Derive revisit incidence, intensity metrics, and powers-of-two file bands."""
    frame = frame.copy()
    frame["any_revisit"] = (frame.revisited_files > 0).astype(int)
    frame["revisited_fraction"] = frame.revisited_files / frame.file_count
    # Every touched file already contributes its first touch; count only possible revisits.
    denominator = frame.file_count * (frame.commit_count - 1)
    frame["extra_touch_fraction"] = (
        frame.file_commit_events - frame.file_count
    ) / denominator.replace(0, np.nan)
    frame["revisited_churn_share"] = frame.revisited_churn / (
        frame.additions + frame.deletions
    ).replace(0, np.nan)
    frame["file_band"] = np.floor(np.log2(frame.file_count)).astype(int)
    for metric in METRICS:
        values = frame[metric].dropna()
        if not values.between(0, 1).all():
            raise ValueError("Out-of-range metric: " + metric)
    return frame


def contrasts(frame, keys, group, levels, metrics, minimum=2):
    """Cell mean differences requiring >= minimum nonmissing PRs on both sides."""
    result = []
    for metric in metrics:
        stats = frame.groupby(keys + [group], observed=True)[metric].agg(["mean", "count"])
        means = stats["mean"].unstack(group).reindex(columns=levels)
        counts = stats["count"].unstack(group).reindex(columns=levels).fillna(0)
        keep = (counts >= minimum).all(axis=1)
        cell = means.loc[keep].copy()
        cell["contrast"] = cell[levels[1]] - cell[levels[0]]
        cell["n_left"] = counts.loc[keep, levels[0]]
        cell["n_right"] = counts.loc[keep, levels[1]]
        cell["metric"] = metric
        result.append(cell.reset_index()[keys + ["metric", "contrast", "n_left", "n_right"]])
    return pd.concat(result, ignore_index=True)


def summarize(cells, name, repetitions, seed):
    """Average cells equally within repository, then repositories equally, with bootstrap CIs."""
    rows, repositories = [], []
    for metric, subset in cells.groupby("metric", sort=True):
        repo = subset.groupby("repo_url").contrast.mean()
        values = repo.to_numpy()
        rng = np.random.default_rng(seed)
        draws = np.array(
            [rng.choice(values, size=len(values), replace=True).mean() for _ in range(repetitions)]
        )
        low, high = np.quantile(draws, [0.025, 0.975]) if len(values) >= 2 else (np.nan, np.nan)
        rows.append(
            dict(
                analysis=name,
                metric=metric,
                estimate=float(values.mean()),
                ci_low=float(low),
                ci_high=float(high),
                repositories=len(repo),
                cells=len(subset),
                prs=int((subset.n_left + subset.n_right).sum()),
                positive=int((values > 0).sum()),
                negative=int((values < 0).sum()),
                tied=int((values == 0).sum()),
            )
        )
        repositories.extend(
            dict(analysis=name, metric=metric, repo_url=key, contrast=float(value))
            for key, value in repo.items()
        )
    return rows, repositories


def revisit_eligibility_checks(frame, exact_cells, band_cells):
    """Score coarser comparisons on the exact PRs admitted by finer matching."""
    month_keys = BASE[:2]
    band_keys = BASE + ["file_band"]
    exact_support = exact_cells.loc[exact_cells.metric.eq("any_revisit"), BASE]
    band_support = band_cells.loc[band_cells.metric.eq("any_revisit"), band_keys]
    exact_months = frame.merge(
        exact_support[month_keys].drop_duplicates(), on=month_keys, validate="many_to_one"
    )
    exact_prs = frame.merge(exact_support, on=BASE, validate="many_to_one")
    band_prs = exact_prs.merge(band_support, on=band_keys, validate="many_to_one")
    expected_band_prs = (
        band_cells.loc[band_cells.metric.eq("any_revisit"), ["n_left", "n_right"]].sum().sum()
    )
    if len(band_prs) != expected_band_prs:
        raise ValueError("File-band support must be contained in the exact-commit support")

    band_metrics = ("any_revisit",)
    if "revisited_fraction" in frame.columns:
        band_metrics = ("any_revisit", "revisited_fraction")

    analyses = {}
    for name, sample, keys, metrics in (
        ("all_closed_prs", frame, month_keys, ("any_revisit",)),
        ("all_prs_in_exact_commit_months", exact_months, month_keys, ("any_revisit",)),
        (
            "multi_prs_in_exact_commit_months",
            exact_months.loc[exact_months.commit_count.ge(2)],
            month_keys,
            ("any_revisit",),
        ),
        ("exact_commit_sample_by_month", exact_prs, month_keys, ("any_revisit",)),
        ("file_band_sample_by_exact_commits", band_prs, BASE, band_metrics),
    ):
        analyses[name] = contrasts(sample, keys, "agent", AGENTS, metrics)

    membership = exact_prs[["id", "agent", *band_keys]].copy()
    membership["in_exact_commit_sample"] = True
    membership["in_file_band_sample"] = membership.id.isin(band_prs.id)
    membership = membership.sort_values([*band_keys, "agent", "id"]).reset_index(drop=True)
    return analyses, membership


def verify_paired_pr_ids(
    frame, membership, exact_by_month_cells, exact_cells, band_by_exact_cells, band_cells
):
    """Assert that both paired comparisons use identical PR IDs before and after matching."""
    month_keys = BASE[:2]
    band_keys = BASE + ["file_band"]

    exact_member_ids = set(membership.loc[membership["in_exact_commit_sample"], "id"])
    exact_after_ids = set(
        frame.merge(
            exact_cells.loc[exact_cells.metric.eq("any_revisit"), BASE],
            on=BASE,
            validate="many_to_one",
        )["id"]
    )
    exact_before_ids = set(
        frame.loc[frame["id"].isin(exact_member_ids)].merge(
            exact_by_month_cells.loc[exact_by_month_cells.metric.eq("any_revisit"), month_keys],
            on=month_keys,
            validate="many_to_one",
        )["id"]
    )
    if not (exact_before_ids == exact_after_ids == exact_member_ids):
        raise ValueError("Exact-commit paired comparison PR IDs do not match before and after")

    band_member_ids = set(membership.loc[membership["in_file_band_sample"], "id"])
    band_after_ids = set(
        frame.merge(
            band_cells.loc[band_cells.metric.eq("any_revisit"), band_keys],
            on=band_keys,
            validate="many_to_one",
        )["id"]
    )
    band_before_ids = set(
        frame.loc[frame["id"].isin(band_member_ids)].merge(
            band_by_exact_cells.loc[band_by_exact_cells.metric.eq("any_revisit"), BASE],
            on=BASE,
            validate="many_to_one",
        )["id"]
    )
    if not (band_before_ids == band_after_ids == band_member_ids):
        raise ValueError("File-band paired comparison PR IDs do not match before and after")

    return {
        "exact_commit_before_prs": len(exact_before_ids),
        "exact_commit_after_prs": len(exact_after_ids),
        "exact_commit_identical_pr_ids": True,
        "file_band_before_prs": len(band_before_ids),
        "file_band_after_prs": len(band_after_ids),
        "file_band_identical_pr_ids": True,
    }


def paired_revisit_change(coarse, fine, metrics=("any_revisit",)):
    """Pair the repository-level estimate change on one fixed PR sample."""
    columns = ["contrast", "n_left", "n_right"]
    aggregation = {"contrast": "mean", "n_left": "sum", "n_right": "sum"}
    counts = ["n_left", "n_right"]
    parts = []
    for metric in metrics:
        c = coarse.loc[coarse.metric.eq(metric)].groupby("repo_url")[columns].agg(aggregation)
        f = fine.loc[fine.metric.eq(metric)].groupby("repo_url")[columns].agg(aggregation)
        if not c.index.equals(f.index) or not np.array_equal(c[counts], f[counts]):
            raise ValueError(
                f"Paired comparisons require the same per-agent PR counts in each repository ({metric})"
            )
        parts.append(f.assign(contrast=f.contrast - c.contrast, metric=metric).reset_index())
    return pd.concat(parts, ignore_index=True)


def historical_file_band_sensitivity(frame, *, seed=20261120):
    """Reproduce the historical +12.19 pp / 58-repo alternate file-band specification.

    Uses coarse file bands (1, 2-3, 4-10, 11+) and requires positive churn
    (additions + deletions > 0) before cell formation.
    """
    multi_positive = frame.loc[
        frame.commit_count.ge(2) & (frame.additions + frame.deletions).gt(0)
    ].copy()
    multi_positive["historical_file_band"] = pd.cut(
        multi_positive.file_count,
        bins=HISTORICAL_BAND_EDGES,
        labels=HISTORICAL_BAND_LABELS,
    )
    cells = contrasts(
        multi_positive, BASE + ["historical_file_band"], "agent", AGENTS, ("any_revisit",)
    )
    rows = []
    for name, reps in (
        ("historical_file_band_10000", 10000),
        ("historical_file_band_2000", 2000),
    ):
        summary_rows, _ = summarize(cells, name, reps, seed)
        row = dict(summary_rows[0])
        row["bootstrap_draws"] = reps
        row["file_bands"] = "1, 2-3, 4-10, 11+"
        row["churn_eligibility"] = "additions + deletions > 0 required for all metrics"
        rows.append(row)
    return pd.DataFrame(rows)
