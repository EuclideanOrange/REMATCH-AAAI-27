"""AIDev file-revisit analysis, matching eligibility checks, and canonical outputs.

Usage:
    python -m experiments.aidev_revisit_extensions OUTPUT \
        --features cache/aidev_inputs/expanded/aidev_features.jsonl \
        --pilot cache/aidev_inputs/pilot/aidev_cohort.jsonl \
        --raw cache/raw/aidev

OUTPUT must not already exist. Raw SQLite staging and per-PR metrics stay under
ignored cache/; canonical tables, PR membership, audit metadata, report, and the
manuscript main figure (read strictly from summary.csv) are written to OUTPUT.
"""

import argparse
import json
from pathlib import Path

import pandas as pd

from data.aidev_history import stage
from data.utils import AIDEV_CONFIG, file_sha256, read_rows
from experiments.revisit_analysis import (
    AGENTS,
    BASE,
    METRICS,
    contrasts,
    derive,
    historical_file_band_sensitivity,
    paired_revisit_change,
    revisit_eligibility_checks,
    summarize,
    verify_paired_pr_ids,
)
from experiments.revisit_artifacts import verify_against_reference, write_report


def write_analysis_tables(frame, audit, output, *, repetitions, seed):
    """Compute and write the matching analyses, sensitivity results, and coverage."""
    multi = frame[frame.commit_count >= 2].copy()
    summaries, repository_rows, coverage = [], [], []

    def save(name, cells, *, paired=False):
        cells.to_csv(output / (name + "_cells.csv"), index=False)
        rows, repos = summarize(cells, name, repetitions, seed)
        if paired:
            for row in rows:
                row["cells"] = None
        summaries.extend(rows)
        repository_rows.extend(repos)

    keys = BASE + ["file_band"]
    exact_cells = contrasts(multi, BASE, "agent", AGENTS, METRICS)
    all_cells = contrasts(multi, keys, "agent", AGENTS, METRICS)
    save("exact_commits", exact_cells)
    save("exact_commits_file_band", all_cells)

    eligibility, membership = revisit_eligibility_checks(frame, exact_cells, all_cells)
    audit["paired_comparisons"] = verify_paired_pr_ids(
        frame,
        membership,
        eligibility["exact_commit_sample_by_month"],
        exact_cells,
        eligibility["file_band_sample_by_exact_commits"],
        all_cells,
    )
    (output / "audit.json").write_text(json.dumps(audit, indent=2) + "\n", encoding="utf-8")
    membership.to_csv(output / "matching_pr_membership.csv", index=False)

    for name, cells in eligibility.items():
        save(name, cells)
    save(
        "paired_exact_commit_change",
        paired_revisit_change(eligibility["exact_commit_sample_by_month"], exact_cells),
        paired=True,
    )
    save(
        "paired_file_band_change",
        paired_revisit_change(
            eligibility["file_band_sample_by_exact_commits"],
            all_cells,
            metrics=("any_revisit", "revisited_fraction"),
        ),
        paired=True,
    )

    single = multi[multi.provenance_flag == "single_recorded_author"]
    single_cells = contrasts(single, keys, "agent", AGENTS, METRICS)
    common = all_cells.merge(
        single_cells, on=keys + ["metric"], suffixes=("_all", "_single"), validate="one_to_one"
    )
    for label in ("all", "single"):
        cells = common[keys + ["metric"]].copy()
        for column in ("contrast", "n_left", "n_right"):
            cells[column] = common[column + "_" + label]
        save("author_common_" + label, cells)
    delta = common[keys + ["metric"]].copy()
    delta["contrast"] = common.contrast_single - common.contrast_all
    delta["n_left"] = common.n_left_single
    delta["n_right"] = common.n_right_single
    save("author_common_single_minus_all", delta)

    for agent in AGENTS:
        subset = multi[multi.agent == agent]
        save(
            "merge_association_" + agent,
            contrasts(subset, keys, "any_revisit", (0, 1), ("merged",)),
        )

    for agent, subset in frame.groupby("agent"):
        coverage.append(
            dict(
                agent=agent,
                prs=len(subset),
                repositories=int(subset.repo_url.nunique()),
                multi_commit=int((subset.commit_count >= 2).sum()),
                multi_single_author=int(
                    (
                        (subset.commit_count >= 2)
                        & (subset.provenance_flag == "single_recorded_author")
                    ).sum()
                ),
                zero_churn=int((subset.additions + subset.deletions == 0).sum()),
            )
        )

    pd.DataFrame(coverage).to_csv(output / "coverage.csv", index=False)
    pd.DataFrame(summaries).to_csv(output / "summary.csv", index=False)
    pd.DataFrame(repository_rows).to_csv(output / "repository_contrasts.csv", index=False)
    historical_file_band_sensitivity(frame, seed=seed).to_csv(
        output / "alternate_specifications.csv", index=False
    )
    return summaries


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("output", type=Path)
    parser.add_argument(
        "--features",
        type=Path,
        default=Path("cache/aidev_inputs/expanded/aidev_features.jsonl"),
    )
    parser.add_argument(
        "--pilot",
        type=Path,
        default=Path("cache/aidev_inputs/pilot/aidev_cohort.jsonl"),
    )
    parser.add_argument("--raw", type=Path, default=Path("cache/raw/aidev"))
    parser.add_argument(
        "--staging",
        type=Path,
        default=None,
        help="Optional fresh staging directory (defaults to cache/<output.name>_staging).",
    )
    parser.add_argument("--bootstrap", type=int, default=2000)
    parser.add_argument("--seed", type=int, default=20261120)
    parser.add_argument(
        "--verify-reference",
        type=Path,
        default=None,
        help="Optional saved reference run directory to verify against and record verification.json.",
    )
    parser.add_argument(
        "--manuscript-figure",
        type=Path,
        default=None,
        help="Optional extra path to write the manuscript PDF figure (e.g. manuscript/main_figure.pdf).",
    )
    args = parser.parse_args()
    if args.bootstrap < 100:
        parser.error("Use at least 100 bootstrap repetitions")

    args.output.mkdir(parents=True, exist_ok=False)
    staging = args.staging or (Path("cache") / (args.output.name + "_staging"))
    staging.mkdir(parents=True, exist_ok=False)

    pilot_repos = {r["repo_url"] for r in read_rows(args.pilot)}
    frame = pd.DataFrame(
        r
        for r in read_rows(args.features)
        if r["agent"] in AGENTS and r["repo_url"] not in pilot_repos
    )
    if frame.id.duplicated().any():
        raise ValueError("Duplicate PR IDs")

    protocol = dict(
        status="exploratory; hypotheses selected after reading prior AIDev results",
        dataset=AIDEV_CONFIG["dataset"],
        revision=AIDEV_CONFIG["revision"],
        snapshot_end=AIDEV_CONFIG["snapshot_end"],
        agents=list(AGENTS),
        seed=args.seed,
        bootstrap=args.bootstrap,
        cohort=(
            "Retained closed PRs outside all original pilot repositories; "
            "exact-commit and file-band checks use multi-commit PRs"
        ),
        eligibility="Both sides have >=2 nonmissing PRs per cell, separately per metric",
        weighting="Equal eligible cells within repository, then equal repositories",
        contrasts=(
            "Codex minus Claude; single-author minus all on common cells; "
            "revisit minus no revisit for merge"
        ),
        matching=(
            "repository, creation month, exact commit count; "
            "main file-band analysis uses powers-of-two floor(log2(file_count)): 1, 2-3, 4-7, 8-15, ..."
        ),
        churn_eligibility=(
            "Zero-churn PRs included for any_revisit, revisited_fraction, and extra_touch_fraction; "
            "revisited_churn_share undefined at zero churn and evaluated separately per metric"
        ),
        matching_eligibility=(
            "Add grouping only after restricting the coarse comparison to the same PR IDs as "
            "the finer comparison. Estimate the paired difference using the same repository resamples."
        ),
        bootstrap_unit="repository, percentile 95% intervals; seed reset per metric for paired draws",
        definitions=dict(
            any_revisit="at least one path in >1 distinct recorded commit",
            revisited_fraction="revisited unique paths / all unique paths",
            extra_touch_fraction="(unique commit-path events - unique paths) / (unique paths * (commits - 1))",
            revisited_churn_share="all additions+deletions on revisited paths / total; includes first touch; undefined at zero churn",
        ),
        limitations=[
            "No causal interpretation or independently validated task controls",
            "Paths, not changed lines; renames are distinct paths; author count does not establish human/AI identity",
            "Recorded commits need not all occur after PR opening; no ordering or timing inferred",
            "Single-author selection and file bands can change task composition",
            "Intervals exploratory, unadjusted for multiple comparisons; no confirmatory significance claims",
            "Merge association may reflect complexity, review feedback, or selection into retained cohort",
        ],
        features_sha256=file_sha256(args.features),
        pilot_sha256=file_sha256(args.pilot),
    )
    (args.output / "protocol.json").write_text(
        json.dumps(protocol, indent=2) + "\n", encoding="utf-8"
    )

    raw_features, audit = stage(args.raw, set(frame.id), staging / "records.sqlite")
    frame = frame.merge(raw_features, on="id", how="left", validate="one_to_one")
    for original, recomputed in [
        ("file_count", "audited_file_count"),
        ("commit_count", "audited_commit_count"),
        ("additions", "audited_additions"),
        ("deletions", "audited_deletions"),
    ]:
        mismatch = int((frame[original] != frame[recomputed]).sum())
        audit[original + "_mismatches"] = mismatch
        if mismatch:
            raise ValueError(f"{mismatch} mismatches for {original}")
    frame = derive(frame)
    audit.update(
        prs=len(frame),
        repositories=int(frame.repo_url.nunique()),
        excluded_pilot_repositories=len(pilot_repos),
    )
    frame.to_csv(staging / "pr_metrics.csv", index=False)

    summaries = write_analysis_tables(
        frame, audit, args.output, repetitions=args.bootstrap, seed=args.seed
    )

    write_report(args.output, manuscript_figure=args.manuscript_figure)

    if args.verify_reference is not None:
        verification = verify_against_reference(args.output, args.verify_reference)
        (args.output / "verification.json").write_text(
            json.dumps(verification, indent=2) + "\n", encoding="utf-8"
        )
        print("Verified against reference:", args.verify_reference, flush=True)

    print(pd.DataFrame(summaries).to_string(index=False), flush=True)
    print("Finished:", args.output, flush=True)


if __name__ == "__main__":
    main()
