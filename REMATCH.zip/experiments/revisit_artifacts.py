"""Verify saved revisit results and render the report and manuscript figure."""

import json
from pathlib import Path

import pandas as pd

from data.utils import AIDEV_CONFIG
from experiments.revisit_analysis import AGENTS, METRICS
from figures.main_figure import render_main_figure


def verify_against_reference(output_dir, reference_dir, *, tolerance=1e-12):
    """Check canonical outputs against the saved reference run and membership invariants."""
    output_dir = Path(output_dir)
    reference_dir = Path(reference_dir)

    new_summary = pd.read_csv(output_dir / "summary.csv")
    ref_summary = pd.read_csv(reference_dir / "summary.csv")
    merged = ref_summary.merge(
        new_summary, on=["analysis", "metric"], suffixes=("_ref", "_new"), how="left"
    )
    if merged["estimate_new"].isna().any():
        missing = merged.loc[merged["estimate_new"].isna(), ["analysis", "metric"]].to_dict(
            "records"
        )
        raise ValueError(f"Missing reference rows in canonical summary.csv: {missing}")

    max_diffs = {}
    for col in ("estimate", "ci_low", "ci_high"):
        diff = float((merged[f"{col}_ref"] - merged[f"{col}_new"]).abs().max())
        max_diffs[col] = diff
        if diff > tolerance:
            raise ValueError(f"Reference mismatch in summary.{col}: max diff {diff}")

    for col in ("repositories", "cells", "prs", "positive", "negative", "tied"):
        if not (merged[f"{col}_ref"] == merged[f"{col}_new"]).all():
            raise ValueError(f"Reference integer mismatch in summary.{col}")

    new_rc = pd.read_csv(output_dir / "repository_contrasts.csv")
    ref_rc = pd.read_csv(reference_dir / "repository_contrasts.csv")
    rc_merged = ref_rc.merge(
        new_rc, on=["analysis", "metric", "repo_url"], suffixes=("_ref", "_new"), how="left"
    )
    if rc_merged["contrast_new"].isna().any():
        raise ValueError("Missing repository contrast rows relative to reference run")
    rc_max_diff = float((rc_merged["contrast_ref"] - rc_merged["contrast_new"]).abs().max())
    if rc_max_diff > tolerance:
        raise ValueError(f"Reference mismatch in repository_contrasts: max diff {rc_max_diff}")

    ref_audit = json.loads((reference_dir / "audit.json").read_text(encoding="utf-8"))
    new_audit = json.loads((output_dir / "audit.json").read_text(encoding="utf-8"))
    for key, value in ref_audit.items():
        if new_audit.get(key) != value:
            raise ValueError(
                f"Audit mismatch for {key}: expected {value}, got {new_audit.get(key)}"
            )

    ref_cov = pd.read_csv(reference_dir / "coverage.csv")
    new_cov = pd.read_csv(output_dir / "coverage.csv")
    if not ref_cov.equals(new_cov):
        raise ValueError("coverage.csv does not match reference run")

    membership = pd.read_csv(output_dir / "matching_pr_membership.csv")
    if membership["id"].duplicated().any():
        raise ValueError("Duplicate PR IDs in matching_pr_membership.csv")

    exact_row = new_summary.loc[
        (new_summary.analysis == "exact_commits") & (new_summary.metric == "any_revisit")
    ].iloc[0]
    band_row = new_summary.loc[
        (new_summary.analysis == "exact_commits_file_band") & (new_summary.metric == "any_revisit")
    ].iloc[0]
    exact_mem_count = int(membership["in_exact_commit_sample"].sum())
    band_mem_count = int(membership["in_file_band_sample"].sum())
    if exact_mem_count != int(exact_row["prs"]) or band_mem_count != int(band_row["prs"]):
        raise ValueError("matching_pr_membership.csv counts disagree with summary.csv")

    return {
        "reference_dir": reference_dir.name,
        "summary_rows_checked": int(len(merged)),
        "repository_contrasts_checked": int(len(rc_merged)),
        "max_abs_diff": {**max_diffs, "repository_contrast": rc_max_diff},
        "audit_raw_counts_match": True,
        "coverage_exact_match": True,
        "paired_exact_commit_prs": exact_mem_count,
        "paired_file_band_prs": band_mem_count,
        "paired_comparisons_audit": new_audit.get("paired_comparisons", {}),
    }


def write_report(output, *, manuscript_figure=None):
    """Render report.txt and the manuscript figure strictly from saved CSV/JSON outputs."""
    output = Path(output)
    summary = pd.read_csv(output / "summary.csv")
    audit = json.loads((output / "audit.json").read_text(encoding="utf-8"))
    protocol = json.loads((output / "protocol.json").read_text(encoding="utf-8"))

    def get(analysis, metric):
        return summary[(summary.analysis == analysis) & (summary.metric == metric)].iloc[0]

    def describe(analysis, metric):
        row = get(analysis, metric)
        cells = f", {int(row.cells)} cells" if pd.notna(row.cells) else ""
        return (
            f"{100 * row.estimate:+.2f} percentage points "
            f"(exploratory 95% interval {100 * row.ci_low:+.2f} to {100 * row.ci_high:+.2f}); "
            f"{int(row.repositories)} repositories{cells}, {int(row.prs):,} PRs"
        )

    report = [
        "AIDev file-revisit study — canonical summary report",
        "",
        "DATA AND VALIDATION",
        f"Dataset: {AIDEV_CONFIG['dataset']} @ {AIDEV_CONFIG['revision']} (closed before {AIDEV_CONFIG['snapshot_end']}).",
        f"Recomputed {audit['prs']:,} PRs in {audit['repositories']:,} repositories, excluding all "
        f"{audit['excluded_pilot_repositories']} original pilot repositories.",
        f"Scanned {audit['pr_commit_details']['scanned']:,} file records; deduplicated "
        f"{audit['duplicate_file_rows']:,} identical records.",
        "Zero conflicting file records, missing/extra commit SHAs, or mismatches with saved file counts, "
        "commit counts, additions, and deletions.",
        "",
        "METHOD",
        "A file revisit occurs when the same path appears in >=2 distinct recorded commits of a PR.",
        "Compare Claude Code and OpenAI Codex within repository-month strata requiring >=2 nonmissing "
        "PRs per agent per cell. Average cells equally within repository, then repositories equally.",
        f"Intervals resample repositories {protocol['bootstrap']:,} times (seed {protocol['seed']}).",
        "Main file-band analysis uses powers-of-two bands floor(log2(file_count)): 1, 2-3, 4-7, 8-15, ... "
        "and includes zero-churn PRs for revisit incidence, revisited fraction, and extra-touch fraction "
        "(only revisited_churn_share excludes zero-churn PRs).",
        "",
        "REVISIT INCIDENCE AND MATCHING ELIGIBILITY (CODEX MINUS CLAUDE CODE)",
    ]
    for name, label in (
        ("all_closed_prs", "All eligible closed PRs (repo-month, incl. single-commit)"),
        ("all_prs_in_exact_commit_months", "All PRs in exact-commit-supported repo-months"),
        ("multi_prs_in_exact_commit_months", "Multi-commit PRs in those repo-months"),
        ("exact_commit_sample_by_month", "Fixed exact-commit PRs, grouped by repo-month"),
        ("exact_commits", "Same PRs, adding exact commit count"),
        ("paired_exact_commit_change", "Paired change from adding exact commit count"),
        ("file_band_sample_by_exact_commits", "Fixed file-band PRs, grouped by exact commit count"),
        ("exact_commits_file_band", "Same PRs, adding powers-of-two file-count bands"),
        ("paired_file_band_change", "Paired change from adding file-count bands"),
    ):
        report.append(f"{label}: {describe(name, 'any_revisit')}.")

    report.extend(
        [
            "",
            "REVISIT INTENSITY METRICS (EXACT COMMIT COUNT / FILE-BAND)",
        ]
    )
    for analysis in ("exact_commits", "exact_commits_file_band"):
        for metric in METRICS:
            report.append(f"{analysis}, {metric}: {describe(analysis, metric)}.")

    report.extend(
        [
            "",
            "AUTHOR SENSITIVITY ON IDENTICAL ELIGIBLE CELLS",
            "All recorded-author configurations: "
            + describe("author_common_all", "any_revisit")
            + ".",
            "Single recorded author: " + describe("author_common_single", "any_revisit") + ".",
            "Paired change (single minus all): "
            + describe("author_common_single_minus_all", "any_revisit")
            + ".",
            "",
            "MERGE ASSOCIATIONS: REVISIT MINUS NO REVISIT",
        ]
    )
    for agent in AGENTS:
        report.append(agent + ": " + describe("merge_association_" + agent, "merged") + ".")

    alt_path = output / "alternate_specifications.csv"
    if alt_path.is_file():
        alt = pd.read_csv(alt_path)
        hist = alt.loc[alt.analysis == "historical_file_band_10000"].iloc[0]
        report.extend(
            [
                "",
                "HISTORICAL ALTERNATE FILE-BAND SPECIFICATION",
                f"Coarse bands (1, 2-3, 4-10, 11+) with positive-churn restriction (10,000 draws): "
                f"{100 * hist.estimate:+.2f} percentage points "
                f"(exploratory 95% interval {100 * hist.ci_low:+.2f} to {100 * hist.ci_high:+.2f}); "
                f"{int(hist.repositories)} repositories, {int(hist.cells)} cells, {int(hist.prs):,} PRs.",
            ]
        )

    report.extend(
        [
            "",
            "ARTIFACTS",
            "summary.csv: canonical estimates, intervals, support, and repository sign counts.",
            "repository_contrasts.csv: repository-level contrasts for every analysis and metric.",
            "matching_pr_membership.csv: exact PR IDs entering both paired comparisons (4,312 and 1,851 PRs).",
            "alternate_specifications.csv: historical +12.19 pp / 58-repository file-band specification.",
            "audit.json, protocol.json, coverage.csv, *_cells.csv: full data audit and cell inputs.",
            "main_figure.pdf and main_figure.png: manuscript figure rendered directly from summary.csv.",
            "",
        ]
    )
    (output / "report.txt").write_text("\n".join(report), encoding="utf-8")

    render_main_figure(
        output / "summary.csv",
        output / "main_figure.pdf",
        png_path=output / "main_figure.png",
    )
    if manuscript_figure is not None:
        render_main_figure(output / "summary.csv", Path(manuscript_figure))
