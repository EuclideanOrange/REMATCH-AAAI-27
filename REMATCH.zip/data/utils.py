"""Pinned AIDev configuration and lightweight I/O helpers."""

import csv
import gzip
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

AIDEV_CONFIG = {
    "dataset": "hao-li/AIDev",
    "revision": "b8dc67df93e7c11f6f20c84129db7232eb1ec253",
    "snapshot_end": "2026-04-01T00:00:00Z",
    "seed": 20261108,
    "max_repositories": 200,
    "max_prs_per_agent_repository": 20,
    "min_prs_per_agent_repository": 3,
    "max_missing_commit_fraction": 0.0,
}

AIDEV_PARQUET_SHA256 = {
    "repository.parquet": "1c84f195fd9813c4bb2c1f2436a9dde71329348f23b5ddd7b92f66125e626f3d",
    "pull_request.parquet": "a9341e2ef692ae4220830b046da228000becc623a1591c5634728d78c331c32b",
    "pr_commits.parquet": "381add099897bded6281b1968cc128646a6c6e223cb529d253f1cbd6b585bd21",
    "pr_commit_details.parquet": "feec2f74de1ea7a43d7b2a07daac54e02ddac4cf83808cc0f6c296ff5c95cb51",
}

AIDEV_PARQUET_FILES = tuple(AIDEV_PARQUET_SHA256)


def write_json(path, value):
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(
        json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + "\n",
        encoding="utf-8",
    )


def write_rows(path, records):
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open("w", encoding="utf-8") as handle:
        for row in records:
            handle.write(json.dumps(row, sort_keys=True, allow_nan=False) + "\n")


def read_rows(path):
    """Stream records from a plain or gzip-compressed JSONL file."""
    path = Path(path)
    open_rows = gzip.open if path.suffix == ".gz" else open
    with open_rows(path, "rt", encoding="utf-8") as handle:
        for line in handle:
            if line.strip():
                yield json.loads(line)


def file_sha256(path):
    hasher = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            hasher.update(block)
    return hasher.hexdigest()


def parse_utc_timestamp(value):
    if not value:
        return None
    try:
        parsed = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
        return parsed.astimezone(timezone.utc) if parsed.tzinfo else None
    except (ValueError, TypeError):
        return None


def stable_key(seed, value):
    return hashlib.sha256(f"{seed}:{value}".encode()).hexdigest()


def csv_write(path, records):
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    if not records:
        target.write_text("", encoding="utf-8")
        return
    with target.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(records[0]))
        writer.writeheader()
        writer.writerows(records)


class ParquetSource:
    """Stream required columns from local or pinned Hugging Face AIDev Parquets."""

    def __init__(self, config, local_dir=None):
        self.config = config
        self.local_dir = Path(local_dir) if local_dir else None
        self.manifest = {}

    def scan(self, table, columns):
        import pyarrow.parquet as pq

        if self.local_dir:
            path = self.local_dir / f"{table}.parquet"
            identity = {"file": path.name, "sha256": file_sha256(path)}
            handle = path.open("rb")
        else:
            from huggingface_hub import HfFileSystem

            hf_path = f"datasets/{self.config['dataset']}@{self.config['revision']}/{table}.parquet"
            fs = HfFileSystem()
            handle = fs.open(hf_path, "rb", block_size=256 * 1024, cache_type="readahead")
            dataset_root = hf_path.split("@")[0]
            identity = {
                "url": f"https://huggingface.co/{dataset_root}/resolve/{self.config['revision']}/{table}.parquet"
            }

        with handle:
            pf = pq.ParquetFile(handle)
            missing = set(columns) - set(pf.schema_arrow.names)
            if missing:
                raise ValueError(f"{table}: required columns missing: {sorted(missing)}")

            record = dict(
                identity,
                columns=columns,
                total_rows=pf.metadata.num_rows,
                scanned_rows=0,
                scan_completed=False,
            )
            self.manifest[table] = record
            print(
                f"Scanning {table:<20} | Rows: {pf.metadata.num_rows:>10,} | Columns: {len(columns)}",
                flush=True,
            )

            for batch in pf.iter_batches(batch_size=16384, columns=columns):
                data = batch.to_pylist()
                record["scanned_rows"] += len(data)
                yield from data

            record["scan_completed"] = True
