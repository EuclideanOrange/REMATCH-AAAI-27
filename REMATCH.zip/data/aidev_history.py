"""Aggregate PR features and independently audit raw commit-file histories."""

import math
import sqlite3
from collections import Counter, defaultdict
from contextlib import closing
from pathlib import PurePosixPath

import numpy as np
import pandas as pd
import pyarrow as pa
import pyarrow.compute as pc
import pyarrow.parquet as pq

COMMIT_COLS = ["pr_id", "sha", "author", "committer"]
FILE_COLS = ["pr_id", "sha", "filename", "additions", "deletions"]


def is_test(path):
    posix = PurePosixPath(path.lower())
    in_test_dir = any(
        part in ("test", "tests", "__tests__", "testing") for part in posix.parts[:-1]
    )
    return (
        in_test_dir
        or posix.name.startswith("test_")
        or posix.stem.endswith(("_test", ".test", ".spec"))
    )


class CommitFileAggregator:
    """Roll up complete commit-file histories into one feature row per PR."""

    def __init__(self, cohort):
        self.lookup = {pr["id"]: pr for pr in cohort}
        self.file_rows = {}
        self.commits = defaultdict(dict)
        self.errors = defaultdict(set)
        self.audit = Counter()

    def add_commit(self, row):
        pid = row["pr_id"]
        if pid not in self.lookup:
            return
        sha = row.get("sha")
        if not sha:
            self.errors[pid].add("missing_commit_sha")
            return
        authors = (row.get("author"), row.get("committer"))
        previous = self.commits[pid].get(sha)
        if previous and previous != authors:
            self.errors[pid].add("conflicting_commit_metadata")
        self.commits[pid][sha] = authors

    def add_file(self, row):
        pid = row["pr_id"]
        if pid not in self.lookup:
            return
        if not row.get("sha") or not row.get("filename"):
            self.errors[pid].add("missing_file_identity")
            return

        key = (pid, row["sha"], row["filename"])
        try:
            values = (float(row["additions"]), float(row["deletions"]))
            if any(not math.isfinite(val) or val < 0 or val != int(val) for val in values):
                raise ValueError("invalid count")
        except (ValueError, TypeError):
            self.errors[pid].add("invalid_file_counts")
            return

        if key in self.file_rows:
            self.audit["duplicate_commit_file_rows"] += 1
            if self.file_rows[key] != values:
                self.errors[pid].add("conflicting_commit_file_rows")
            return

        self.file_rows[key] = values

    def finish(self, config):
        files = defaultdict(lambda: defaultdict(lambda: [0, 0]))
        detailed_shas = defaultdict(set)

        for (pid, sha, filename), (adds, dels) in self.file_rows.items():
            detailed_shas[pid].add(sha)
            files[pid][filename][0] += adds
            files[pid][filename][1] += dels

        retained_rows = []
        for pid, pr in self.lookup.items():
            commits = set(self.commits[pid])
            details = detailed_shas[pid]
            missing_frac = len(commits - details) / max(1, len(commits))

            if not commits or not details:
                self.errors[pid].add("missing_commit_or_file_history")
            if missing_frac > config["max_missing_commit_fraction"] or (details - commits):
                self.errors[pid].add("commit_file_coverage_mismatch")

            if self.errors[pid]:
                self.audit["excluded_prs"] += 1
                for reason in self.errors[pid]:
                    self.audit["excluded_" + reason] += 1
                continue

            paths = files[pid]
            churn = [a + d for a, d in paths.values()]
            total_churn = sum(churn)
            additions = sum(a for a, _ in paths.values())
            deletions = sum(d for _, d in paths.values())
            n_files = len(paths)

            if n_files > 1 and total_churn > 0:
                entropy = -sum(
                    (val / total_churn) * math.log(val / total_churn) for val in churn if val > 0
                ) / math.log(n_files)
            else:
                entropy = 0.0

            authors = {author for author, _ in self.commits[pid].values() if author}
            unknown_author = any(not author for author, _ in self.commits[pid].values())
            if unknown_author:
                provenance_flag = "unknown_author"
            elif len(authors) > 1:
                provenance_flag = "multiple_authors"
            else:
                provenance_flag = "single_recorded_author"

            row = dict(pr)
            row.update(
                commit_count=len(commits),
                file_count=n_files,
                additions=additions,
                deletions=deletions,
                mean_file_churn=total_churn / n_files,
                max_file_churn=max(churn),
                file_churn_entropy=entropy,
                test_file_fraction=sum(is_test(p) for p in paths) / n_files,
                extension_diversity=len(
                    {PurePosixPath(p).suffix.lower() or "[none]" for p in paths}
                ),
                addition_fraction=additions / total_churn if total_churn else 0.0,
                zero_churn=int(total_churn == 0),
                commit_author_count=len(authors),
                unknown_commit_author=int(unknown_author),
                provenance_flag=provenance_flag,
                size_bin=min(int(math.log2(1 + total_churn)), 20),
            )
            retained_rows.append(row)

        self.audit["retained_prs"] = len(retained_rows)
        audit_summary = dict(self.audit)
        selected_counts = Counter(pr["agent"] for pr in self.lookup.values())
        retained_counts = Counter(pr["agent"] for pr in retained_rows)
        audit_summary["retention_by_agent"] = {
            agent: {"selected": selected_counts[agent], "retained": retained_counts[agent]}
            for agent in sorted(selected_counts)
        }
        return retained_rows, audit_summary


def stage(raw, ids, db):
    """Deduplicate commit-file rows, reject conflicts, and audit commit coverage."""
    with closing(sqlite3.connect(db)) as connection:
        return stage_commit_history(raw, ids, connection)


def stage_commit_history(raw, ids, con):
    # Disposable staging index; not a durable source of record.
    con.execute("PRAGMA journal_mode=OFF")
    con.execute("PRAGMA synchronous=OFF")
    con.execute("PRAGMA cache_size=-64000")
    con.execute("CREATE TABLE commits (pid INTEGER, sha TEXT, PRIMARY KEY(pid,sha)) WITHOUT ROWID")
    con.execute(
        "CREATE TABLE files (pid INTEGER, sha TEXT, path TEXT, a REAL, d REAL, "
        "conflict INTEGER DEFAULT 0, PRIMARY KEY(pid,sha,path)) WITHOUT ROWID"
    )
    wanted = pa.array(sorted(ids), type=pa.int64())
    audit = {}
    for name, columns in (
        ("pr_commits", ["pr_id", "sha"]),
        ("pr_commit_details", ["pr_id", "sha", "filename", "additions", "deletions"]),
    ):
        scanned = selected = 0
        for batch in pq.ParquetFile(raw / (name + ".parquet")).iter_batches(
            batch_size=65536, columns=columns
        ):
            scanned += batch.num_rows
            table = pa.Table.from_batches([batch])
            table = table.filter(pc.is_in(table["pr_id"], value_set=wanted))
            rows = list(zip(*(table[c].to_pylist() for c in columns)))
            selected += len(rows)
            if name == "pr_commits":
                if any(not sha for _, sha in rows):
                    raise ValueError("Missing commit SHA")
                con.executemany("INSERT OR IGNORE INTO commits VALUES (?,?)", rows)
            else:
                for _, sha, path, a, d in rows:
                    if (
                        not sha
                        or not path
                        or any(
                            v is None or not np.isfinite(v) or v < 0 or int(v) != v for v in (a, d)
                        )
                    ):
                        raise ValueError("Invalid commit-file identity or counts")
                con.executemany(
                    """INSERT INTO files(pid,sha,path,a,d) VALUES (?,?,?,?,?)
                    ON CONFLICT(pid,sha,path) DO UPDATE SET conflict =
                    files.conflict OR files.a != excluded.a OR files.d != excluded.d""",
                    rows,
                )
            con.commit()
        audit[name] = {"scanned": scanned, "selected": selected}
        print(name, audit[name], flush=True)

    audit["conflicting_file_rows"] = con.execute(
        "SELECT count(*) FROM files WHERE conflict != 0"
    ).fetchone()[0]
    audit["missing_or_extra_commit_shas"] = (
        con.execute(
            "SELECT count(*) FROM (SELECT pid,sha FROM commits EXCEPT SELECT pid,sha FROM files)"
        ).fetchone()[0]
        + con.execute(
            "SELECT count(*) FROM (SELECT pid,sha FROM files EXCEPT SELECT pid,sha FROM commits)"
        ).fetchone()[0]
    )
    if audit["conflicting_file_rows"] or audit["missing_or_extra_commit_shas"]:
        raise ValueError(audit)

    con.execute(
        "CREATE TABLE paths AS SELECT pid,path,count(*) AS touches, "
        "sum(a) AS a,sum(d) AS d FROM files GROUP BY pid,path"
    )
    features = pd.read_sql_query(
        """SELECT pid AS id,count(*) AS audited_file_count,
        sum(a) AS audited_additions,sum(d) AS audited_deletions,
        sum(touches) AS file_commit_events,sum(touches > 1) AS revisited_files,
        sum(CASE WHEN touches > 1 THEN a+d ELSE 0 END) AS revisited_churn
        FROM paths GROUP BY pid""",
        con,
    )
    commits = pd.read_sql_query(
        "SELECT pid AS id,count(*) AS audited_commit_count FROM commits GROUP BY pid", con
    )
    audit["unique_file_rows"] = con.execute("SELECT count(*) FROM files").fetchone()[0]
    audit["duplicate_file_rows"] = (
        audit["pr_commit_details"]["selected"] - audit["unique_file_rows"]
    )
    return features.merge(commits, on="id", validate="one_to_one"), audit
