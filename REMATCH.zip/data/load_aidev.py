"""Obtain pinned AIDev Parquets and build the pilot-exclusion and feature cohorts.

Usage:
    python -m data.load_aidev --raw cache/raw/aidev --out cache/aidev_inputs [--download]

Outputs under --out:
    pilot/aidev_cohort.jsonl         Original 200-repository pilot exclusion list
    pilot/aidev_cohort_audit.json    Pilot selection counts
    expanded/aidev_cohort.jsonl      Uncapped shared-repository closed-PR cohort
    expanded/aidev_features.jsonl    Uncapped retained feature cohort (100,643 PRs)
    expanded/aidev_cohort_audit.json Expanded selection counts
    expanded/aidev_feature_audit.json Feature extraction and exclusion counts
    manifest.json                    Dataset revision, raw Parquet hashes, output hashes
"""

import argparse
import re
from collections import Counter, defaultdict
from pathlib import Path

from data.aidev_history import COMMIT_COLS, FILE_COLS, CommitFileAggregator
from data.utils import (
    AIDEV_CONFIG,
    AIDEV_PARQUET_FILES,
    AIDEV_PARQUET_SHA256,
    ParquetSource,
    csv_write,
    file_sha256,
    parse_utc_timestamp,
    stable_key,
    write_json,
    write_rows,
)

PR_COLS = [
    "id",
    "number",
    "agent",
    "user",
    "title",
    "state",
    "created_at",
    "closed_at",
    "merged_at",
    "repo_url",
    "html_url",
]


def task_proxy(title):
    text = (title or "").lower()
    patterns = {
        "bug": r"\b(fix|fixes|bug|hotfix|regression)\b",
        "feature": r"\b(feat|feature|add|implement)\b",
        "refactor": r"\b(refactor|refactoring|restructure)\b",
        "docs": r"\b(docs|documentation|readme)\b",
        "test": r"\b(test|tests|testing)\b",
    }
    matches = [key for key, pat in patterns.items() if re.search(pat, text)]
    return matches[0] if len(matches) == 1 else "unknown"


def select_aidev_cohort(pr_rows, repositories, config):
    """Select closed PRs before snapshot_end in multi-agent shared repositories."""
    audit_counts = Counter()
    grouped = defaultdict(list)
    seen = set()
    snapshot_end = parse_utc_timestamp(config["snapshot_end"])

    for pr in pr_rows:
        audit_counts["scanned_prs"] += 1
        if pr["id"] in seen:
            raise ValueError(f"Duplicate PR id {pr['id']}")
        seen.add(pr["id"])

        opened = parse_utc_timestamp(pr.get("created_at"))
        closed = parse_utc_timestamp(pr.get("closed_at"))
        merged = parse_utc_timestamp(pr.get("merged_at"))

        if pr.get("state") != "closed":
            audit_counts["excluded_unresolved"] += 1
            continue

        invalid_meta = (
            not opened
            or not closed
            or not pr.get("agent")
            or not pr.get("repo_url")
            or not (opened <= closed < snapshot_end)
            or (pr.get("merged_at") and not merged)
            or (merged and not (opened <= merged <= closed))
        )
        if invalid_meta:
            audit_counts["excluded_invalid_metadata"] += 1
            continue

        grouped[pr["repo_url"], pr["agent"]].append(pr)

    supported = defaultdict(list)
    for (repo, agent), prs in grouped.items():
        if len(prs) >= config["min_prs_per_agent_repository"]:
            supported[repo].append(agent)

    shared_repos = [repo for repo, agents in supported.items() if len(agents) >= 2]
    shared_repos.sort(key=lambda repo: stable_key(config["seed"], repo))
    chosen_repos = shared_repos[: config["max_repositories"]]

    selected = []
    for repo in chosen_repos:
        for agent in sorted(supported[repo]):
            prs = sorted(
                grouped[repo, agent],
                key=lambda row: stable_key(config["seed"], row["id"]),
            )
            for pr in prs[: config["max_prs_per_agent_repository"]]:
                row = dict(pr)
                row["language"] = (repositories.get(repo) or {}).get("language") or "unknown"
                row["created_month"] = pr["created_at"][:7]
                row["task_proxy"] = task_proxy(pr.get("title"))
                row["merged"] = int(bool(pr.get("merged_at")))
                selected.append(row)

    audit_counts.update(
        shared_repositories_available=len(shared_repos),
        selected_repositories=len(chosen_repos),
        selected_prs=len(selected),
    )

    cohort_audit = {
        "counts": dict(audit_counts),
        "observed_agent_repository_cells": len(grouped),
        "selected_per_agent": dict(Counter(r["agent"] for r in selected)),
    }
    return selected, cohort_audit


def download_pinned_parquets(raw_dir, config=AIDEV_CONFIG):
    """Download the four pinned AIDev Parquet tables from Hugging Face Hub."""
    from huggingface_hub import hf_hub_download

    raw_dir = Path(raw_dir)
    raw_dir.mkdir(parents=True, exist_ok=True)
    for filename in AIDEV_PARQUET_FILES:
        print(
            f"Downloading {filename} from {config['dataset']}@{config['revision']}...", flush=True
        )
        hf_hub_download(
            repo_id=config["dataset"],
            repo_type="dataset",
            revision=config["revision"],
            filename=filename,
            local_dir=str(raw_dir),
        )


def verify_raw_parquets(raw_dir):
    """Compute and verify SHA-256 hashes of the four pinned AIDev Parquet files."""
    raw_dir = Path(raw_dir)
    hashes = {}
    for filename, expected in AIDEV_PARQUET_SHA256.items():
        path = raw_dir / filename
        if not path.is_file():
            raise FileNotFoundError(f"Missing required Parquet file: {path}")
        actual = file_sha256(path)
        if actual != expected:
            raise ValueError(f"SHA-256 mismatch for {filename}: expected {expected}, got {actual}")
        hashes[filename] = {"bytes": path.stat().st_size, "sha256": actual}
    return hashes


def build_revisit_inputs(raw_dir, out_dir, *, config=AIDEV_CONFIG, verify_hashes=False):
    """Build the pilot-exclusion cohort and uncapped expanded feature cohort."""
    raw_dir = Path(raw_dir)
    out_dir = Path(out_dir)
    pilot_dir = out_dir / "pilot"
    expanded_dir = out_dir / "expanded"
    pilot_dir.mkdir(parents=True, exist_ok=True)
    expanded_dir.mkdir(parents=True, exist_ok=True)

    parquet_hashes = verify_raw_parquets(raw_dir) if verify_hashes else None

    source = ParquetSource(config, local_dir=raw_dir)
    repositories = {row["url"]: row for row in source.scan("repository", ["url", "language"])}
    pr_rows = list(source.scan("pull_request", PR_COLS))

    # 1. Original capped pilot cohort (defines the 200 excluded pilot repositories).
    pilot_cohort, pilot_audit = select_aidev_cohort(pr_rows, repositories, config)
    pilot_path = pilot_dir / "aidev_cohort.jsonl"
    write_rows(pilot_path, pilot_cohort)
    write_json(pilot_dir / "aidev_cohort_audit.json", pilot_audit)

    # 2. Uncapped expanded feature cohort across all shared repositories.
    expanded_config = {**config, "max_repositories": None, "max_prs_per_agent_repository": None}
    expanded_cohort, expanded_audit = select_aidev_cohort(pr_rows, repositories, expanded_config)
    expanded_cohort_path = expanded_dir / "aidev_cohort.jsonl"
    write_rows(expanded_cohort_path, expanded_cohort)
    write_json(expanded_dir / "aidev_cohort_audit.json", expanded_audit)

    aggregator = CommitFileAggregator(expanded_cohort)
    for row in source.scan("pr_commits", COMMIT_COLS):
        aggregator.add_commit(row)
    for row in source.scan("pr_commit_details", FILE_COLS):
        aggregator.add_file(row)

    features, feature_audit = aggregator.finish(expanded_config)
    features_path = expanded_dir / "aidev_features.jsonl"
    write_rows(features_path, features)
    write_json(expanded_dir / "aidev_feature_audit.json", feature_audit)

    exclusions = [
        {
            "pr_id": pid,
            "agent": aggregator.lookup[pid]["agent"],
            "repository": aggregator.lookup[pid]["repo_url"],
            "reasons": "|".join(sorted(reasons)),
        }
        for pid, reasons in sorted(aggregator.errors.items())
        if reasons
    ]
    csv_write(expanded_dir / "aidev_feature_exclusions.csv", exclusions)

    manifest = {
        "dataset": config["dataset"],
        "revision": config["revision"],
        "snapshot_end": config["snapshot_end"],
        "seed": config["seed"],
        "pilot_repositories": pilot_audit["counts"]["selected_repositories"],
        "pilot_prs": pilot_audit["counts"]["selected_prs"],
        "expanded_retained_prs": feature_audit["retained_prs"],
        "pilot_cohort_sha256": file_sha256(pilot_path),
        "expanded_features_sha256": file_sha256(features_path),
        "raw_parquets": parquet_hashes
        or {
            f"{table}.parquet": {
                "rows": meta["total_rows"],
                "sha256": meta["sha256"],
            }
            for table, meta in source.manifest.items()
        },
    }
    write_json(out_dir / "manifest.json", manifest)
    return manifest


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--raw",
        type=Path,
        default=Path("cache/raw/aidev"),
        help="Directory holding the four pinned AIDev Parquet files.",
    )
    parser.add_argument(
        "--out",
        type=Path,
        default=Path("cache/aidev_inputs"),
        help="Output directory for pilot/aidev_cohort.jsonl and expanded/aidev_features.jsonl.",
    )
    parser.add_argument(
        "--download",
        action="store_true",
        help="Download the four pinned Parquet tables from Hugging Face Hub before extraction.",
    )
    parser.add_argument(
        "--verify-hashes",
        action="store_true",
        help="Verify each Parquet file against its pinned SHA-256 digest before extraction.",
    )
    args = parser.parse_args()

    if args.download:
        download_pinned_parquets(args.raw)

    manifest = build_revisit_inputs(args.raw, args.out, verify_hashes=args.verify_hashes)
    print(
        f"Prepared pilot cohort ({manifest['pilot_repositories']} repos): {args.out / 'pilot' / 'aidev_cohort.jsonl'}"
    )
    print(f"  SHA-256: {manifest['pilot_cohort_sha256']}")
    print(
        f"Prepared expanded features ({manifest['expanded_retained_prs']:,} PRs): {args.out / 'expanded' / 'aidev_features.jsonl'}"
    )
    print(f"  SHA-256: {manifest['expanded_features_sha256']}")


if __name__ == "__main__":
    main()
